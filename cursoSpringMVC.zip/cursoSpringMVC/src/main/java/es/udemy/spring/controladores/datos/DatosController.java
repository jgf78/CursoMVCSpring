package es.udemy.spring.controladores.datos;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/datos/*")//Mapeo a nivel de clase
public class DatosController {
	
	//Con query-string
	//Pasamos un par�metro porla url y lo recogemos con el requestParam 
	//http://localhost:8080/cursoSpringMVC/datos/parametro?param1=hola
	@RequestMapping(value="/parametro", method=RequestMethod.GET)
	public @ResponseBody String conParametro(@RequestParam String param1){
		return "Valor obtenido del param1: "+param1;
	}
	
	//Con path variable se pasa el el valor del parametro en la url
	//http://localhost:8080/cursoSpringMVC/datos/pathvariable/Julian
	@RequestMapping(value="/pathvariable/{param1}", method=RequestMethod.GET)
	public @ResponseBody String conPathVariable(@PathVariable String param1){
		return "Valor obtenido del param1: "+param1;
	}
	
	//Con matrix variable
	//http://localhost:8080/cursoSpringMVC/datos/Julian;param2=valor2/cualquiercosa
	@RequestMapping(value="/{param1}/cualquiercosa", method=RequestMethod.GET)
	public @ResponseBody String conMatrixVariable(@PathVariable String param1, @MatrixVariable String param2){
		return "Valor obtenido de la variableMatrix= "+param2+"del segundo param1= "+param1;
	}
	
	//Con matrix variable
	//http://localhost:8080/cursoSpringMVC/datos/ruta1;variableMatriz=Dato1/ruta2;variableMatriz=Dato2
	@RequestMapping(value="/{param1}/{param2}", method=RequestMethod.GET)
	public @ResponseBody String conMatrixVariableMultiple(
			@PathVariable String param1, @MatrixVariable(value="variableMatriz", pathVar="param1") String matriz1,
			@PathVariable String param2, @MatrixVariable(value="variableMatriz", pathVar="param1") String matriz2){
		return "Otenida la variableMatriz= "+matriz1+" desde la ruta "+param1
				+" y la variableMatriz= "+matriz2+" desde la ruta "+param2;
	}
	
	//Con cabecera
	//Mostramos la cabecera que acepta el cliente
	//http://localhost:8080/cursoSpringMVC/datos/cabecera
	@RequestMapping(value="/cabecera", method=RequestMethod.GET)
	public @ResponseBody String conCabecera(@RequestHeader String Accept){
		return "Valor obtenido de la cabecera: "+Accept;
	}
	
	//Obtenemos informaci�n del navegador del cliente
	//http://localhost:8080/cursoSpringMVC/datos/cabeceraNavegador
	@RequestMapping(value="/cabeceraNavegador", method=RequestMethod.GET)
	public @ResponseBody String conCabeceraNavegador(@RequestHeader(value="User-Agent") String userAgent){
		return "Valor obtenido de la cabecera: "+userAgent;
	}
	
	//Obtener las cookies, en IE funciona, en el resto no porque tratan las cookies de otra forma
	//http://localhost:8080/cursoSpringMVC/datos/cookie
	@RequestMapping(value="/cookie", method=RequestMethod.GET)
	public @ResponseBody String conCookie(@CookieValue String JSESSIONID){
		return "Valor obtenido de la cookie: "+JSESSIONID;
	}
	
	//Capturar el cuerpo de la petici�n
	//Con body post
	@RequestMapping(value="/body", method=RequestMethod.POST)
	public @ResponseBody String conBody(@RequestBody String body){
		return "Valor obtenido del body: "+body;
	}
	
	//Con body post
	@RequestMapping(value="/entidad", method=RequestMethod.POST)
	public @ResponseBody String conEntidad(HttpEntity<String> entidad){
		return "Valor obtenido del body: "+entidad.getBody() + "valor obtenido de las cabeceras: "+entidad.getHeaders() ;
	}
	
	
}
