package es.udemy.spring.controladores.peticiones;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/multiaccion/*")//Controlador mapeado para todas las acciones
public class MultiaccionController {
	//http://localhost:8080/cursoSpringMVC/multiaccion/path
	@RequestMapping("/path")
	public @ResponseBody String peticionPorPath(){
		return "Petici�n por path";
	}
	
	//http://localhost:8080/cursoSpringMVC/multiaccion/metodo
	@RequestMapping(value="/metodo", method=RequestMethod.GET)
	public @ResponseBody String peticionPorMetodo(){
		return "Petici�n por m�todo";
	}
	
	//http://localhost:8080/cursoSpringMVC/multiaccion/parametro?param1=hola
	@RequestMapping(value="/parametro", method=RequestMethod.GET, params="param1")
	public @ResponseBody String peticionPorParametro(){
		return "Petici�n por presencia de par�metro";
	}
	
	//Mismo mapeo pasando par�metro(comentar uno de los metodos de peticionPorAusenciaDeParametro para probarlo)
	//http://localhost:8080/cursoSpringMVC/multiaccion/parametro?param1=hola
	@RequestMapping(value="/parametro", method=RequestMethod.GET, params="!param1")
	public @ResponseBody String peticionPorAusenciaDeParametro(){		
		return "Petici�n por ausencia de par�metro";
	}
	
	//http://localhost:8080/cursoSpringMVC/multiaccion/sinParametro OK
	//http://localhost:8080/cursoSpringMVC/multiaccion/sinParametro?param1=hola KO
//	@RequestMapping(value="/sinParametro", method=RequestMethod.GET, params="!param1")
//	public @ResponseBody String peticionPorAusenciaDeParametro(){
//		return "Petici�n por ausencia de par�metro";
//	}
	
	//El usuario puede acceder por texto plano
	@RequestMapping(value="/cabecera", method=RequestMethod.GET, headers="Accept=text/plain")
	public @ResponseBody String peticionPorCabecera(){
		return "Petici�n por presencia de cabecera";
	}
	
	//Devuelve el resultado al cliente como un fichero JSON, probadlo con chrome
	//Si en vez de produces usamos "consumes" queremos decir que el usuario tiene que mandar la informacion
	//como JSON, es la inversa al produces, produces devuelve al usuario, consumes envia al usuario.
	@RequestMapping(value="/produces", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String peticionPorProduces(){
		return "Petici�n por produces";
	}
	
	//Debe de ir en �ltimo lugar ya que recoge la raiz de peticiones
	//http://localhost:8080/cursoSpringMVC/multiaccion/
	@RequestMapping(value="/*")
	public @ResponseBody String peticionPorExpresionRegular(){
		return "Petici�n por expresi�n regular";
	}
	
}
