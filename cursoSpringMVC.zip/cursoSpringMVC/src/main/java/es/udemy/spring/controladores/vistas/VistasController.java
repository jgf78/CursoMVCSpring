package es.udemy.spring.controladores.vistas;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/vistas/*")
public class VistasController {
	
	//http://localhost:8080/cursoSpringMVC/vistas/hola
	@RequestMapping("/hola")
	public ModelAndView modelAndView(){
		String mensaje = " Juli�n";
		String mensaje2 = " G�mez Fern�ndez";
		Map<String, String> modelo = new HashMap<>();
		modelo.put("mensaje", mensaje);
		modelo.put("mensaje2", mensaje2);
		//Forma antigua
		//return new ModelAndView("/WEB-INF/jsp/hello.jsp", "modelo", modelo);
		//Forma moderna
		return new ModelAndView("hello", "modelo", modelo);
	}
	
	//http://localhost:8080/cursoSpringMVC/vistas/saludos
	@RequestMapping("/saludos")
	public String vistaUno(Model modelo){
		modelo.addAttribute("mensaje", "Maria");
		modelo.addAttribute("mensaje2", "Pepe");
		return "hello";//es el jsp
	}
	
	//http://localhost:8080/cursoSpringMVC/vistas/saludosDos/Juan/Manuela
	@RequestMapping("/saludosDos/{mensaje}/{mensaje2}")
	public String vistaDos(@PathVariable String mensaje, @PathVariable String mensaje2){
		return "hello";//es el jsp
	}
	
	//http://localhost:8080/cursoSpringMVC/vistas/saludosTres/Juan/Manuela
	@RequestMapping("/saludosTres/{mensaje}/{mensaje2}")
	public String vistaTres(JavaBean bean){
		return "hello";//es el jsp
	}
	
	//http://localhost:8080/cursoSpringMVC/vistas/vistaCuatro
	@RequestMapping("/vistaCuatro")
	public void vistaCuatro(){
		
	}
	
	//http://localhost:8080/cursoSpringMVC/vistas/vistaCinco
	@RequestMapping("/vistaCinco")
	public String vistaCinco(){
		return "vistas/vistaCuatro";	
	}
	
}
