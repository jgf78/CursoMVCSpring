package es.udemy.spring.controladores.conversores;

import java.util.List;
import java.util.Map;

public class Anidado {
	private Integer numero;
	private List<Anidado> listaAnidados;
	private Map<String, Anidado> mapaAnidados;

	@Override
	public String toString() {
		return "Anidado [" + (numero != null ? "numero=" + numero + ", " : "")
				+ (listaAnidados != null ? "listaAnidados=" + listaAnidados + ", " : "")
				+ (mapaAnidados != null ? "mapaAnidados=" + mapaAnidados : "") + "]";
	}

	public Integer getNumero() {
		return numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public List<Anidado> getListaAnidados() {
		return listaAnidados;
	}

	public void setListaAnidados(List<Anidado> listaAnidados) {
		this.listaAnidados = listaAnidados;
	}

	public Map<String, Anidado> getMapaAnidados() {
		return mapaAnidados;
	}

	public void setMapaAnidados(Map<String, Anidado> mapaAnidados) {
		this.mapaAnidados = mapaAnidados;
	}
}
