package es.udemy.spring.controladores.datos;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("datos-estandar")
public class DatosEstandarController {
	
	//Forma cl�sica con el API de Servlet para obtener el valor de los par�metros de entrada
	//http://localhost:8080/cursoSpringMVC/datos-estandar/datos?name=julian
	@RequestMapping("/datos")
	public @ResponseBody String DatosEstandar(HttpServletRequest request, Locale idiomaUsuario){
		String nombre = request.getParameter("name");
		String idioma = idiomaUsuario.getDisplayLanguage();
		return "Nombre: "+nombre+" Idioma: "+idioma;
	}
}
