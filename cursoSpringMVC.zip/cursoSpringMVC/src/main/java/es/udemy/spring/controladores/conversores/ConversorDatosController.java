package es.udemy.spring.controladores.conversores;

import java.util.Collection;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/conversor")
public class ConversorDatosController {
	
	//http://localhost:8080/cursoSpringMVC/conversor/entero?numero=666
	@RequestMapping("/entero")
	public @ResponseBody String entero(@RequestParam Integer numero){
		return "Dato n�merico convertido "+numero;
	}
	
	//http://localhost:8080/cursoSpringMVC/conversor/fecha?fecha=2017-05-01
	@RequestMapping("/fecha")
	public @ResponseBody String fecha(@RequestParam @DateTimeFormat(iso=ISO.DATE) Date fecha){
		return "Dato fecha convertido "+fecha;
	}
	
	//http://localhost:8080/cursoSpringMVC/conversor/fechaPatron?fecha=01-05-2017
	//Con el patr�n dd/MM/yyyy tambien funciona
	@RequestMapping("/fechaPatron")
	public @ResponseBody String fechaPatron(@RequestParam @DateTimeFormat(pattern=("dd-MM-yyyy")) Date fecha){
		return "Dato fecha convertido "+fecha;
	}
	
	//Conversi�n colecci�n de datos
	//N�meros
	//Diferentes formas de pasar los datos a la colecci�n, la mas c�moda es la �ltima
	//http://localhost:8080/cursoSpringMVC/conversor/coleccion?coleccion=50
	//http://localhost:8080/cursoSpringMVC/conversor/coleccion?coleccion=50&coleccion=51
	//http://localhost:8080/cursoSpringMVC/conversor/coleccion?coleccion=50,51,52
	@RequestMapping("/coleccion")
	public @ResponseBody String coleccion(@RequestParam Collection<Integer> coleccion){
		return "Dato coleccion de n�meros convertido "+coleccion;
	}
	
	//Fechas
	//http://localhost:8080/cursoSpringMVC/conversor/coleccionFechas?coleccionFechas=01/05/2017,02/05/2017
	@RequestMapping("/coleccionFechas")
	public @ResponseBody String coleccionFechas(@RequestParam  @DateTimeFormat(pattern=("dd/MM/yyyy"))Collection<Date> coleccionFechas){
		return "Dato coleccion de fechas convertida "+coleccionFechas;
	}
	
	//Objeto propio
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?numero=666
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?numero=666&fecha=01/05/2017
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?numero=666&fecha=01/05/2017&coleccion=5,2,3
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?lista[0]=1&lista[1]=2
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?mapa[100]=julian&mapa[101]=pepe
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?anidado.numero=5
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?anidado.listaAnidados[0].numero=1&anidado.listaAnidados[1].numero=2
	//http://localhost:8080/cursoSpringMVC/conversor/objeto?anidado.mapaAnidados[Julian].numero=1&anidado.mapaAnidados[pepe].numero=2
	@RequestMapping("/objeto")
	public @ResponseBody String objeto(JavaBean bean){
		return "Dato objeto propio convertido "+bean;
	}
}
