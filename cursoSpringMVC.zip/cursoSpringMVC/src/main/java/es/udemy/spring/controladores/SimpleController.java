package es.udemy.spring.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SimpleController {
	@RequestMapping("/hola")
	public @ResponseBody String hola(){
		return "Hola!!!";
	}
	
	@RequestMapping(value="/adios",method=RequestMethod.GET)
	public @ResponseBody String adios(){
		return "Adios!!!";
	}
	
	//El m�todo post no esta soportado, solo se puede acceder por get
	@RequestMapping(value="/adiosError",method=RequestMethod.POST)
	public @ResponseBody String adiosError(){
		return "Adios!!!";
	}
	
}
