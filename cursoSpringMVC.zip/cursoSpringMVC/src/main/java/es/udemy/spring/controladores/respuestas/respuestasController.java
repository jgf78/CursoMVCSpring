package es.udemy.spring.controladores.respuestas;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/respuestas/*")
public class respuestasController {
	
	//http://localhost:8080/cursoSpringMVC/respuestas/path
	@RequestMapping("/path")
	public @ResponseBody String respuestaConResponseBody(){
		return "Respuesta con body de responseBody";
	}
	
	//http://localhost:8080/cursoSpringMVC/respuestas/entidad/estado
	//Para mostrar el mensaje hay que usar el chrome
	@RequestMapping("entidad/estado")
	public ResponseEntity<String> respuestaConResponseEntity(){
		return new ResponseEntity<>("No puedes pasar",HttpStatus.FORBIDDEN);
	}
	
	//http://localhost:8080/cursoSpringMVC/respuestas/entidad/completo
	@RequestMapping("entidad/completo")
	public ResponseEntity<String> respuestaConResponseEntityCompleto(){
		HttpHeaders cabeceras = new HttpHeaders();
		cabeceras.setContentType(MediaType.TEXT_HTML);
		return new ResponseEntity<>("<h1>Mensaje de la p�gina</h1>",cabeceras,HttpStatus.OK);
	}
	
	
}
