package es.udemy.spring.controladores.peticiones;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PeticionesController {

	@RequestMapping("/peticiones/path")
	public @ResponseBody String peticionPorPath(){
		return "Petici�n por path";
	}
	
	@RequestMapping(value="/peticiones/metodo", method=RequestMethod.GET)
	public @ResponseBody String peticionPorMetodo(){
		return "Petici�n por m�todo";
	}
	
	//http://localhost:8080/cursoSpringMVC/peticiones/parametro?param1=hola
	@RequestMapping(value="/peticiones/parametro", method=RequestMethod.GET, params="param1")
	public @ResponseBody String peticionPorParametro(){
		return "Petici�n por presencia de par�metro";
	}
	
	//Mismo mapeo pasando par�metro(comentar uno de los metodos de peticionPorAusenciaDeParametro para probarlo)
	//http://localhost:8080/cursoSpringMVC/peticiones/parametro?param1=hola
	@RequestMapping(value="/peticiones/parametro", method=RequestMethod.GET, params="!param1")
	public @ResponseBody String peticionPorAusenciaDeParametro(){		
		return "Petici�n por ausencia de par�metro";
	}
	
	//http://localhost:8080/cursoSpringMVC/peticiones/sinParametro OK
	//http://localhost:8080/cursoSpringMVC/peticiones/sinParametro?param1=hola KO
//	@RequestMapping(value="/peticiones/sinParametro", method=RequestMethod.GET, params="!param1")
//	public @ResponseBody String peticionPorAusenciaDeParametro(){
//		return "Petici�n por ausencia de par�metro";
//	}
	
	//El usuario puede acceder por texto plano
	@RequestMapping(value="/peticiones/cabecera", method=RequestMethod.GET, headers="Accept=text/plain")
	public @ResponseBody String peticionPorCabecera(){
		return "Petici�n por presencia de cabecera";
	}
	
	//Devuelve el resultado al cliente como un fichero JSON, probadlo con chrome
	//Si en vez de produces usamos "consumes" queremos decir que el usuario tiene que mandar la informacion
	//como JSON, es la inversa al produces, produces devuelve al usuario, consumes envia al usuario.
	@RequestMapping(value="/peticiones/produces", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String peticionPorProduces(){
		return "Petici�n por produces";
	}
	
	//Debe de ir en �ltimo lugar ya que recoge la raiz de peticiones
	//http://localhost:8080/cursoSpringMVC/peticiones/
	@RequestMapping(value="/peticiones/*")
	public @ResponseBody String peticionPorExpresionRegular(){
		return "Petici�n por expresi�n regular";
	}
	
}
