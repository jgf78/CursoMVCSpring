package es.udemy.spring.controladores.conversores.mensajes;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rometools.rome.feed.atom.Feed;
import com.rometools.rome.feed.rss.Channel;


@Controller
@RequestMapping("/conversor-mensajes/*")
public class ConversorMensajesController {
	
	//Hay que probarlo con el chrome, el navegador interno no lo soporta
	//Formato XML
	//http://localhost:8080/cursoSpringMVC/conversor-mensajes/xml
	@RequestMapping(value="/xml", method=RequestMethod.GET)
	public @ResponseBody JavaBean xml(){
		return new JavaBean("manzanas","citroen");
	}
	
	//Formato JSON
	//http://localhost:8080/cursoSpringMVC/conversor-mensajes/json
	@RequestMapping(value="/json", method=RequestMethod.GET)
	public @ResponseBody JavaBean json(){
		return new JavaBean("peras","seat");
	}
	
	//Formato atom
	//http://localhost:8080/cursoSpringMVC/conversor-mensajes/atom
	@RequestMapping(value="/atom", method=RequestMethod.GET)
	public @ResponseBody Feed atom(){
		Feed feed = new Feed();
		feed.setFeedType("atom_1.0");
		feed.setTitle("Titulo de atom");
		return feed;
	}
	
	//Formato rss
	//http://localhost:8080/cursoSpringMVC/conversor-mensajes/rss
	@RequestMapping(value="/rss", method=RequestMethod.GET)
	public @ResponseBody Channel rss(){
		Channel canal = new Channel();
		canal.setFeedType("rss_2.0");
		canal.setTitle("Titulo de rss");
		canal.setDescription("Descripci�n de RSS");
		canal.setLink("www.marca.com");
		return canal;
	}
}
